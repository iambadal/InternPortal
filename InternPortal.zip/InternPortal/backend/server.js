// Simple Express server that returns polished static JSON data
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const data = require('./data.json');
const leaderboard = require('./leaderboard.json');

app.get('/api/user', (req, res) => {
  res.json(data);
});

app.get('/api/leaderboard', (req, res) => {
  res.json(leaderboard);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
