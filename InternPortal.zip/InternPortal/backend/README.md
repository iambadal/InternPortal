# Backend - Donation Tracker (Polished Demo)

## Requirements
- Node.js (v14+ recommended)
- npm

## Install & Run
1. Install dependencies:
```
npm install
```
2. Start the server:
```
npm start
```
3. Open `http://localhost:3000/api/user` and `http://localhost:3000/api/leaderboard` to view JSON responses.

This server returns static JSON and is intended for development/demo purposes only.
