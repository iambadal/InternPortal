# Donation Tracker — Polished Internship Project

This is a polished frontend + simple backend demo for the internship assignment. Design aims to look like a modern, professional dashboard suitable for submission.

## Folder structure
```
donation-tracker-polished/
├── frontend/
│   ├── index.html
│   ├── dashboard.html
│   ├── leaderboard.html
│   ├── style.css
│   ├── script.js
│   └── assets/logo.svg
└── backend/
    ├── server.js
    ├── data.json
    ├── leaderboard.json
    └── package.json
```

## Quick start
- Frontend: open `frontend/index.html` in a browser (or deploy `frontend/` to GitHub Pages).
- Backend (optional): run the Node server to serve API data for the frontend.
  ```
  cd backend
  npm install
  npm start
  ```
The frontend will use the backend when available; otherwise it falls back to static demo data.

## Notes for submission
- Upload the entire folder to GitHub and enable GitHub Pages for the `frontend/` folder for a live demo.
- Update `backend/data.json` with real values if you want different demo data.
