// Polished script.js for demo frontend
const API_ROOT = 'http://localhost:3000/api';

async function fetchAndPopulate(){
  try{
    const res = await fetch(API_ROOT + '/user');
    if(!res.ok) throw new Error('no backend');
    const data = await res.json();
    applyUserData(data);
  }catch(e){
    console.warn('Backend not available, using fallback data.');
    const fallback = { name: localStorage.getItem('donation_intern_name') || 'Badal Pujhari', referralCode: 'badal2025', totalDonations: 10000 };
    applyUserData(fallback);
  }
}

function applyUserData(data){
  const name = data.name || localStorage.getItem('donation_intern_name') || 'Intern';
  document.getElementById('displayName').textContent = name;
  const userNameEl = document.getElementById('userName');
  if(userNameEl) userNameEl.textContent = name;
  document.getElementById('refCode').textContent = data.referralCode || '-';
  document.getElementById('totalDonations').textContent = (data.totalDonations !== undefined) ? '₹' + data.totalDonations : '₹0';
}

async function fetchLeaderboard(){
  try{
    const res = await fetch(API_ROOT + '/leaderboard');
    if(!res.ok) throw new Error('no backend');
    const list = await res.json();
    populateLeaderboard(list);
  }catch(e){
    const fallback = [
      { "rank": 1, "name": "Badal Pujhari", "donations": 10000 },
      { "rank": 2, "name": "John Doe", "donations": 8000 },
      { "rank": 3, "name": "Jane Smith", "donations": 6500 }
    ];
    populateLeaderboard(fallback);
  }
}

function populateLeaderboard(list){
  const tbody = document.querySelector('#leaderboardTable tbody');
  if(!tbody) return;
  tbody.innerHTML = '';
  list.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${item.rank}</td><td>${item.name}</td><td>₹${item.donations}</td>`;
    tbody.appendChild(tr);
  });
}
